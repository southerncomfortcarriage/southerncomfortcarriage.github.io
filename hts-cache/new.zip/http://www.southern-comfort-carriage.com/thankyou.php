<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<head>
		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
		<title>Southern Comfort Carriage Service: Thank You</title>
		<script type="text/javascript" src="/scripts/global.js"></script>
		<meta name="keywords" content="horse, carriage, buggy, ride, wedding, special event, birthday, limo, limousine,  nashville, tn, tennessee, special transportation, activity, tourist, tour, educational, nite-life, nite life, princess, cowboy">
		<meta name="description" content="Southern Comfort Carriage Service is one of the premier Horse and Carriage ride services for individual or small group tour rides through downtown Nashville, or at your special event in the surrounding areas. Weddings, birthdays, and more... a horse and carriage ride always makes that special occasion even better!">
		<link href="/styles/global.css" rel="stylesheet" media="screen">
		<script type="text/javascript"><!--
function preloadImagesCmp001AB3F576() {
	if (document.images) {
		over_home = newImage(/*URL*/'/images/nav/home_over.jpg');
		over_about = newImage(/*URL*/'/images/nav/about_over.jpg');
		over_rates = newImage(/*URL*/'/images/nav/rates_over.jpg');
		over_events = newImage(/*URL*/'/images/nav/events_over.jpg');
		over_horses = newImage(/*URL*/'/images/nav/horses_over.jpg');
		over_contact = newImage(/*URL*/'/images/nav/contact_over.jpg');
		over_photos = newImage(/*URL*/'/images/nav/photos_over.jpg');
	}
}
// --></script>
		
		
		<script language="JavaScript" name="Rotator"><!--
	function loadImage() {
		var iNdx;
		var sVal;
		iNdx = Math.round(Math.random() * 3) + 1;
		sVal = "corner" + iNdx + ".jpg"
		document.write('<img src="/images/' + sVal + '" name="rotatingimage" width="200" height="110" border="0" alt="rotatingimage">');
		}
	// -->
</script>
		<script type="text/javascript"><!--
var preloadFlag = false;
function preloadImages() {
	if(document.images) {
		preloadImagesCmp001AB3F576();
		preloadFlag = true;
	}
}
// --></script>
		
	</head>

	<body onload="preloadImages();" background="/images/background.gif" bgcolor="#ffffff" leftmargin="0" marginheight="0" marginwidth="0" topmargin="0">
		<table width="700" border="0" cellspacing="0" cellpadding="0">
			<tr valign="top">
				<td width="200">
					<script language="JavaScript" name="Rotation">
	<!-- //
		loadImage();
	// -->
</script>
				</td>
				<td><img src="/images/title.gif" alt="Southern Comfort Carriage Service" width="500" height="110" border="0"></td>
			</tr>
			<tr valign="top">
				<td width="200">
					<p><br>
						<img src="/images/nav/navtop.jpg" alt="Nav Top" width="195" height="60" border="0"><br>
						<a onmouseover="changeImages( /*CMP*/'home',/*URL*/'/images/nav/home_over.jpg');return true" onmouseout="changeImages( /*CMP*/'home',/*URL*/'/images/nav/home.jpg');return true" href="/index.html"><img src="/images/nav/home.jpg" alt="Home" name="home" width="195" height="30" border="0"></a><br>
						<a onmouseover="changeImages( /*CMP*/'about',/*URL*/'/images/nav/about_over.jpg');return true" onmouseout="changeImages( /*CMP*/'about',/*URL*/'/images/nav/about.jpg');return true" href="/about.htm"><img src="/images/nav/about.jpg" alt="About Us" name="about" width="195" height="30" border="0"></a><br>
						<a onmouseover="changeImages( /*CMP*/'rates',/*URL*/'/images/nav/rates_over.jpg');return true" onmouseout="changeImages( /*CMP*/'rates',/*URL*/'/images/nav/rates.jpg');return true" href="/rates.htm"><img src="/images/nav/rates.jpg" alt="Rates &amp; Schedules" name="rates" width="195" height="30" border="0"></a><br>
						<a onmouseover="changeImages( /*CMP*/'events',/*URL*/'/images/nav/events_over.jpg');return true" onmouseout="changeImages( /*CMP*/'events',/*URL*/'/images/nav/events.jpg');return true" href="/events.htm"><img src="/images/nav/events.jpg" alt="Your Special Events" name="events" width="195" height="30" border="0"></a><br>
						<a onmouseover="changeImages( /*CMP*/'horses',/*URL*/'/images/nav/horses_over.jpg');return true" onmouseout="changeImages( /*CMP*/'horses',/*URL*/'/images/nav/horses.jpg');return true" href="/horses.htm"><img src="/images/nav/horses.jpg" alt="Horses &amp; Carriages" name="horses" width="195" height="30" border="0"></a><br>
						<a onmouseover="changeImages( /*CMP*/'contact',/*URL*/'/images/nav/contact_over.jpg');return true" onmouseout="changeImages( /*CMP*/'contact',/*URL*/'/images/nav/contact.jpg');return true" href="/contact.htm"><img src="/images/nav/contact.jpg" alt="Contact Us" name="contact" width="195" height="30" border="0"></a><br>
						<a onmouseover="changeImages( /*CMP*/'photos',/*URL*/'/images/nav/photos_over.jpg');return true" onmouseout="changeImages( /*CMP*/'photos',/*URL*/'/images/nav/photos.jpg');return true" href="/photos.htm"><img src="/images/nav/photos.jpg" alt="Photos" name="photos" width="195" height="30" border="0"></a><br>
						<img src="/images/nav/navbutt.jpg" alt="Nav Butt" width="195" height="65" border="0"><br>
						<br>
					</p>
					
					<div align="center">
						<p><br>
						</p>
					</div>
				</td>
				<td>
					<div align="center">
						<img src="/images/headings/contact.gif" alt="Contact Us" width="195" height="30" border="0"></div>
					<p><br>
					</p>
					<p><b>Success! Thank You!</b></p>
					<p>Your form submission was sent successfully. Thank you very much for your message! We will respond appropriatly as soon as possible.</p>
					<p>Below are the results of what you sent us. If you notice any typos in your contact information, please go back and resubmit the form with your corrected info. Thanks again!</p>
					<blockquote>
						<hr>
						