<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

	<!-- #BeginTemplate "../../../../SouthernComfort.data/Templates/template.htm" -->

		<head>
			<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
			<title>Southern Comfort Carriage Service: Photos</title>
		<script type="text/javascript" src="../../../scripts/global.js"></script>
		<meta name="keywords" content="horse, carriage, buggy, ride, wedding, special event, birthday, limo, limousine,  nashville, tn, tennessee, special transportation, activity, tourist, tour, educational, nite-life, nite life, princess, cowboy">
		<meta name="description" content="Southern Comfort Carriage Service is one of the premier Horse and Carriage ride services for individual or small group tour rides through downtown Nashville, or at your special event in the surrounding areas. Weddings, birthdays, and more... a horse and carriage ride always makes that special occasion even better!">
		<link href="../../../styles/global.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" type="text/css" href="templates/default/main.css" />
		<link rel="Top" title="Albums" href="index.php?gallery=." />
		<script type="text/javascript"><!--
function preloadImagesCmp001AB3F576() {
	if (document.images) {
		over_home = newImage(/*URL*/'../../../images/nav/home_over.jpg');
		over_about = newImage(/*URL*/'../../../images/nav/about_over.jpg');
		over_rates = newImage(/*URL*/'../../../images/nav/rates_over.jpg');
		over_events = newImage(/*URL*/'../../../images/nav/events_over.jpg');
		over_horses = newImage(/*URL*/'../../../images/nav/horses_over.jpg');
		over_contact = newImage(/*URL*/'../../../images/nav/contact_over.jpg');
		over_photos = newImage(/*URL*/'../../../images/nav/photos_over.jpg');
	}
}
// --></script>
		
		
		<script language="JavaScript" name="Rotator"><!--
	function loadImage() {
		var iNdx;
		var sVal;
		iNdx = Math.round(Math.random() * 3) + 1;
		sVal = "corner" + iNdx + ".jpg"
		document.write('<img src="../images/' + sVal + '" name="rotatingimage" width="200" height="110" border="0" alt="rotatingimage">');
		}
	// -->
</script>
		<script type="text/javascript"><!--
var preloadFlag = false;
function preloadImages() {
	if(document.images) {
		preloadImagesCmp001AB3F576();
		preloadFlag = true;
	}
}
// --></script>
		
		</head>

		<body onload="preloadImages();" background="../../../images/background.gif" bgcolor="#ffffff" leftmargin="0" marginheight="0" marginwidth="0" topmargin="0">
			<table width="700" border="0" cellspacing="0" cellpadding="0">
				<tr valign="top">
					<td width="200">
						<script language="JavaScript" name="Rotation">
	<!-- //
		loadImage();
	// -->
</script>
					</td>
					<td><img src="../../../images/title.gif" alt="Southern Comfort Carriage Service" width="500" height="110" border="0"></td>
				</tr>
				<tr valign="top">
					<td width="200">
					<p><br>
						<img src="../../../images/nav/navtop.jpg" alt="Nav Top" width="195" height="60" border="0"><br>
						<a onmouseover="changeImages( /*CMP*/'home',/*URL*/'../../../images/nav/home_over.jpg');return true" onmouseout="changeImages( /*CMP*/'home',/*URL*/'../../../images/nav/home.jpg');return true" href="../../../index.html"><img src="../../../images/nav/home.jpg" alt="Home" name="home" width="195" height="30" border="0"></a><br>
						<a onmouseover="changeImages( /*CMP*/'about',/*URL*/'../../../images/nav/about_over.jpg');return true" onmouseout="changeImages( /*CMP*/'about',/*URL*/'../../../images/nav/about.jpg');return true" href="../../../about.htm"><img src="../../../images/nav/about.jpg" alt="About Us" name="about" width="195" height="30" border="0"></a><br>
						<a onmouseover="changeImages( /*CMP*/'rates',/*URL*/'../../../images/nav/rates_over.jpg');return true" onmouseout="changeImages( /*CMP*/'rates',/*URL*/'../../../images/nav/rates.jpg');return true" href="../../../rates.htm"><img src="../../../images/nav/rates.jpg" alt="Rates &amp; Schedules" name="rates" width="195" height="30" border="0"></a><br>
						<a onmouseover="changeImages( /*CMP*/'events',/*URL*/'../../../images/nav/events_over.jpg');return true" onmouseout="changeImages( /*CMP*/'events',/*URL*/'../../../images/nav/events.jpg');return true" href="../../../events.htm"><img src="../../../images/nav/events.jpg" alt="Your Special Events" name="events" width="195" height="30" border="0"></a><br>
						<a onmouseover="changeImages( /*CMP*/'horses',/*URL*/'../../../images/nav/horses_over.jpg');return true" onmouseout="changeImages( /*CMP*/'horses',/*URL*/'../../../images/nav/horses.jpg');return true" href="../../../horses.htm"><img src="../../../images/nav/horses.jpg" alt="Horses &amp; Carriages" name="horses" width="195" height="30" border="0"></a><br>
						<a onmouseover="changeImages( /*CMP*/'contact',/*URL*/'../../../images/nav/contact_over.jpg');return true" onmouseout="changeImages( /*CMP*/'contact',/*URL*/'../../../images/nav/contact.jpg');return true" href="../../../contact.htm"><img src="../../../images/nav/contact.jpg" alt="Contact Us" name="contact" width="195" height="30" border="0"></a><br>
						<a onmouseover="changeImages( /*CMP*/'photos',/*URL*/'../../../images/nav/photos_over.jpg');return true" onmouseout="changeImages( /*CMP*/'photos',/*URL*/'../../../images/nav/photos.jpg');return true" href="../../../photos.htm"><img src="../../../images/nav/photos.jpg" alt="Photos" name="photos" width="195" height="30" border="0"></a><br>
						<img src="../../../images/nav/navbutt.jpg" alt="Nav Butt" width="195" height="65" border="0"><br>
						<br>
					</p>
					
						<div align="center">
							<p><br>
							</p>
						</div>
					</td>
					<td><!-- #BeginEditable "Content" -->
							<div align="center">
								<img src="../../../images/headings/photos.gif" alt="Photos" width="195" height="30" border="0"></div>
							<p><br>
							</p>
<h1 style="margin-bottom: 0px">Photo Album</h1>
<p style="margin-top: 0;"></p>

<div class="sgShadow"><table class="sgShadow" cellspacing="0">
  <tr>
    <td><img src="templates/default/images/shadow-tabl.gif" alt="" /></td>
    <td class="tabm"><table class="sgShadowTab" cellspacing="0"><tr><td>
  
    Showing 1-12 of 12  
    </td><td><img src="templates/default/images/shadow-tabr.gif" alt="" /></td></tr></table></td>
    <td class="tabr"><img src="templates/default/images/blank.gif" alt="" /></td>
  </tr>
  <tr>
    <td class="tl"><img src="templates/default/images/blank.gif" width="32" height="16" alt="" /></td>
    <td class="tm"><img src="templates/default/images/blank.gif" alt="" /></td>
    <td class="tr"><img src="templates/default/images/blank.gif" alt="" /></td>
  </tr>
  <tr>
    <td class="ml"><img src="templates/default/images/blank.gif" alt="" /></td>
    <td class="mm">
  
        <div class="sgThumbnail">
      <div class="sgThumbnailContent">
        <img class="borderTL" src="templates/default/images/slide-tl.gif" alt="" />
        <img class="borderTR" src="templates/default/images/slide-tr.gif" alt="" />
        
        <table><tr><td>
                    <a href="index.php?gallery=.&amp;image=carriage01.jpg"><img src="thumb.php?gallery=.&amp;image=carriage01.jpg&amp;width=100&amp;height=100" width="100" height="75" alt="carriage01" title="carriage01" /></a>        </td></tr></table>
        
        <div class="roundedCornerSpacer">&nbsp;</div>
      </div>
      <div class="bottomCorners">
        <img class="borderBL" src="templates/default/images/slide-bl.gif" alt="" />
        <img class="borderBR" src="templates/default/images/slide-br.gif" alt="" />
      </div>
    </div>
        <div class="sgThumbnail">
      <div class="sgThumbnailContent">
        <img class="borderTL" src="templates/default/images/slide-tl.gif" alt="" />
        <img class="borderTR" src="templates/default/images/slide-tr.gif" alt="" />
        
        <table><tr><td>
                    <a href="index.php?gallery=.&amp;image=scan01.jpg"><img src="thumb.php?gallery=.&amp;image=scan01.jpg&amp;width=100&amp;height=100" width="100" height="71" alt="scan01" title="scan01" /></a>        </td></tr></table>
        
        <div class="roundedCornerSpacer">&nbsp;</div>
      </div>
      <div class="bottomCorners">
        <img class="borderBL" src="templates/default/images/slide-bl.gif" alt="" />
        <img class="borderBR" src="templates/default/images/slide-br.gif" alt="" />
      </div>
    </div>
        <div class="sgThumbnail">
      <div class="sgThumbnailContent">
        <img class="borderTL" src="templates/default/images/slide-tl.gif" alt="" />
        <img class="borderTR" src="templates/default/images/slide-tr.gif" alt="" />
        
        <table><tr><td>
                    <a href="index.php?gallery=.&amp;image=scan02.jpg"><img src="thumb.php?gallery=.&amp;image=scan02.jpg&amp;width=100&amp;height=100" width="100" height="57" alt="scan02" title="scan02" /></a>        </td></tr></table>
        
        <div class="roundedCornerSpacer">&nbsp;</div>
      </div>
      <div class="bottomCorners">
        <img class="borderBL" src="templates/default/images/slide-bl.gif" alt="" />
        <img class="borderBR" src="templates/default/images/slide-br.gif" alt="" />
      </div>
    </div>
        <div class="sgThumbnail">
      <div class="sgThumbnailContent">
        <img class="borderTL" src="templates/default/images/slide-tl.gif" alt="" />
        <img class="borderTR" src="templates/default/images/slide-tr.gif" alt="" />
        
        <table><tr><td>
                    <a href="index.php?gallery=.&amp;image=scan03.jpg"><img src="thumb.php?gallery=.&amp;image=scan03.jpg&amp;width=100&amp;height=100" width="100" height="70" alt="scan03" title="scan03" /></a>        </td></tr></table>
        
        <div class="roundedCornerSpacer">&nbsp;</div>
      </div>
      <div class="bottomCorners">
        <img class="borderBL" src="templates/default/images/slide-bl.gif" alt="" />
        <img class="borderBR" src="templates/default/images/slide-br.gif" alt="" />
      </div>
    </div>
        <div class="sgThumbnail">
      <div class="sgThumbnailContent">
        <img class="borderTL" src="templates/default/images/slide-tl.gif" alt="" />
        <img class="borderTR" src="templates/default/images/slide-tr.gif" alt="" />
        
        <table><tr><td>
                    <a href="index.php?gallery=.&amp;image=scan04.jpg"><img src="thumb.php?gallery=.&amp;image=scan04.jpg&amp;width=100&amp;height=100" width="89" height="100" alt="scan04" title="scan04" /></a>        </td></tr></table>
        
        <div class="roundedCornerSpacer">&nbsp;</div>
      </div>
      <div class="bottomCorners">
        <img class="borderBL" src="templates/default/images/slide-bl.gif" alt="" />
        <img class="borderBR" src="templates/default/images/slide-br.gif" alt="" />
      </div>
    </div>
        <div class="sgThumbnail">
      <div class="sgThumbnailContent">
        <img class="borderTL" src="templates/default/images/slide-tl.gif" alt="" />
        <img class="borderTR" src="templates/default/images/slide-tr.gif" alt="" />
        
        <table><tr><td>
                    <a href="index.php?gallery=.&amp;image=scan05.jpg"><img src="thumb.php?gallery=.&amp;image=scan05.jpg&amp;width=100&amp;height=100" width="94" height="100" alt="scan05" title="scan05" /></a>        </td></tr></table>
        
        <div class="roundedCornerSpacer">&nbsp;</div>
      </div>
      <div class="bottomCorners">
        <img class="borderBL" src="templates/default/images/slide-bl.gif" alt="" />
        <img class="borderBR" src="templates/default/images/slide-br.gif" alt="" />
      </div>
    </div>
        <div class="sgThumbnail">
      <div class="sgThumbnailContent">
        <img class="borderTL" src="templates/default/images/slide-tl.gif" alt="" />
        <img class="borderTR" src="templates/default/images/slide-tr.gif" alt="" />
        
        <table><tr><td>
                    <a href="index.php?gallery=.&amp;image=scan06.jpg"><img src="thumb.php?gallery=.&amp;image=scan06.jpg&amp;width=100&amp;height=100" width="45" height="100" alt="scan06" title="scan06" /></a>        </td></tr></table>
        
        <div class="roundedCornerSpacer">&nbsp;</div>
      </div>
      <div class="bottomCorners">
        <img class="borderBL" src="templates/default/images/slide-bl.gif" alt="" />
        <img class="borderBR" src="templates/default/images/slide-br.gif" alt="" />
      </div>
    </div>
        <div class="sgThumbnail">
      <div class="sgThumbnailContent">
        <img class="borderTL" src="templates/default/images/slide-tl.gif" alt="" />
        <img class="borderTR" src="templates/default/images/slide-tr.gif" alt="" />
        
        <table><tr><td>
                    <a href="index.php?gallery=.&amp;image=scan07.jpg"><img src="thumb.php?gallery=.&amp;image=scan07.jpg&amp;width=100&amp;height=100" width="100" height="69" alt="scan07" title="scan07" /></a>        </td></tr></table>
        
        <div class="roundedCornerSpacer">&nbsp;</div>
      </div>
      <div class="bottomCorners">
        <img class="borderBL" src="templates/default/images/slide-bl.gif" alt="" />
        <img class="borderBR" src="templates/default/images/slide-br.gif" alt="" />
      </div>
    </div>
        <div class="sgThumbnail">
      <div class="sgThumbnailContent">
        <img class="borderTL" src="templates/default/images/slide-tl.gif" alt="" />
        <img class="borderTR" src="templates/default/images/slide-tr.gif" alt="" />
        
        <table><tr><td>
                    <a href="index.php?gallery=.&amp;image=scan08.jpg"><img src="thumb.php?gallery=.&amp;image=scan08.jpg&amp;width=100&amp;height=100" width="100" height="75" alt="scan08" title="scan08" /></a>        </td></tr></table>
        
        <div class="roundedCornerSpacer">&nbsp;</div>
      </div>
      <div class="bottomCorners">
        <img class="borderBL" src="templates/default/images/slide-bl.gif" alt="" />
        <img class="borderBR" src="templates/default/images/slide-br.gif" alt="" />
      </div>
    </div>
        <div class="sgThumbnail">
      <div class="sgThumbnailContent">
        <img class="borderTL" src="templates/default/images/slide-tl.gif" alt="" />
        <img class="borderTR" src="templates/default/images/slide-tr.gif" alt="" />
        
        <table><tr><td>
                    <a href="index.php?gallery=.&amp;image=scan09.jpg"><img src="thumb.php?gallery=.&amp;image=scan09.jpg&amp;width=100&amp;height=100" width="100" height="70" alt="scan09" title="scan09" /></a>        </td></tr></table>
        
        <div class="roundedCornerSpacer">&nbsp;</div>
      </div>
      <div class="bottomCorners">
        <img class="borderBL" src="templates/default/images/slide-bl.gif" alt="" />
        <img class="borderBR" src="templates/default/images/slide-br.gif" alt="" />
      </div>
    </div>
        <div class="sgThumbnail">
      <div class="sgThumbnailContent">
        <img class="borderTL" src="templates/default/images/slide-tl.gif" alt="" />
        <img class="borderTR" src="templates/default/images/slide-tr.gif" alt="" />
        
        <table><tr><td>
                    <a href="index.php?gallery=.&amp;image=scan10.jpg"><img src="thumb.php?gallery=.&amp;image=scan10.jpg&amp;width=100&amp;height=100" width="100" height="75" alt="scan10" title="scan10" /></a>        </td></tr></table>
        
        <div class="roundedCornerSpacer">&nbsp;</div>
      </div>
      <div class="bottomCorners">
        <img class="borderBL" src="templates/default/images/slide-bl.gif" alt="" />
        <img class="borderBR" src="templates/default/images/slide-br.gif" alt="" />
      </div>
    </div>
        <div class="sgThumbnail">
      <div class="sgThumbnailContent">
        <img class="borderTL" src="templates/default/images/slide-tl.gif" alt="" />
        <img class="borderTR" src="templates/default/images/slide-tr.gif" alt="" />
        
        <table><tr><td>
                    <a href="index.php?gallery=.&amp;image=scan11.jpg"><img src="thumb.php?gallery=.&amp;image=scan11.jpg&amp;width=100&amp;height=100" width="100" height="75" alt="scan11" title="scan11" /></a>        </td></tr></table>
        
        <div class="roundedCornerSpacer">&nbsp;</div>
      </div>
      <div class="bottomCorners">
        <img class="borderBL" src="templates/default/images/slide-bl.gif" alt="" />
        <img class="borderBR" src="templates/default/images/slide-br.gif" alt="" />
      </div>
    </div>
      
    </td>
    <td class="mr"><img src="templates/default/images/blank.gif" alt="" /></td>
  </tr>
  <tr>
    <td class="bl"><img src="templates/default/images/blank.gif" alt="" /></td>
    <td class="bm"><img src="templates/default/images/blank.gif" alt="" /></td>
    <td class="br"><img src="templates/default/images/blank.gif" width="32" height="32" alt="" /></td>
  </tr>
</table></div>
  
  
<p>
</p>
							<p></p>
						<!-- #EndEditable --></td>
				</tr>
				<tr valign="top">
					<td colspan="2">
						<div align="center">
							<hr width="90%">
							<span class="footer">[ <a href="../../../index.html">Home</a> | <a href="../../../about.htm">About Us</a> | <a href="../../../rates.htm">Rates &amp; Schedules</a> | <a href="../../../events.htm">Your Special Events</a> | <a href="../../../horses.htm">Horses &amp; Carriages</a> | <a href="../../../photos.htm">Photos</a> | <a href="../../../contact.htm">Contact Us</a> ]</span>
							<hr width="75%">
							<span class="footer"><a href="../../../admin/index.html">&copy;</a> Copyright 2004 Paul Morrison | <a href="../../../credits.htm">Web Credits</a></span><br>
							<img src="../../../images/logo.gif" alt="Logo" width="229" height="145" border="0"></div>
					</td>
				</tr>
			</table>
		</body>

	<!-- #EndTemplate -->

</html>


